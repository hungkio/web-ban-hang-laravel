$(document).ready(function(){
    $('#list_guest').DataTable();
});
