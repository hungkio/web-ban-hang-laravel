<header>

    <div class="gb-header_myichi">

        <div class="gb-header_myichi-topbar">

            <div class="container">

                <div class="row">

                    <div class="col-md-10">

                        <div class="gb-header_myichi-topbar-left">

                            <ul style="text-align: right;">

                                <li><i class="fa fa-map-marker" aria-hidden="true"></i>Giao hàng toàn quốc cung cấp sỉ/lẻ </li>

                                <li><i class="fa fa-phone" aria-hidden="true"></i> Hotline: 0931 45 35 75 - Hỗ trợ 24/7</li>
                                <li><i class="fa fa-paper-plane" aria-hidden="true"></i>  Đổi trả lên đến 15 ngày
                                </li>


                            </ul>

                        </div>

                    </div>

                    <!-- <div class="col-md-3">

                        <div class="gb-header_myichi-topbar-right">

                            <ul>

                                <li>

                                    <a href="/login" title="">

                                        <i class="fa fa-user" aria-hidden="true"></i> Đăng nhập

                                    </a>

                                </li>

                                <li>

                                    <a href="/register" title="">

                                        <i class="fa fa-sign-in" aria-hidden="true"></i> Đăng ký

                                    </a>

                                </li>

                                <li></li>

                            </ul>

                        </div>

                    </div> -->

                    <div class="col-md-2">

                        <div class="gb-header_myichi-cart_myichi">
                            <a href="/gio-hang" title="">
                                <i class="fa fa-shopping-bag" aria-hidden="true"></i> Giỏ hàng (0)
                            </a>
                        </div>

                    </div>

                </div>

            </div>

        </div>



        <div class="gb-header-bottom_myichi sticky-menu">

            <div class="container">

                <div class="gb-header-bottom_myichi-left">

                    <h1><a href="/"><img src="{{asset('images/logo2.png')}}" alt="" class="img-responsive"></a></h1>

                </div>

                <div class="gb-header-bottom_myichi-right">

                    <nav class="gb-main-menu" >
                        <div class="main-navigation uni-menu-text">
                            <div class="cssmenu">
                                <ul>
                                    <li><a href="#">Trang chủ</a></li>
                                    <li><a href="#">Sản phẩm</a></li>
                                    <li class="has-sub"><a href="#">Chương trình khuyến mại</a></li>
                                    <li><a href="#">Báo cáo</a></li>
                                    <li><a href="#">Đăng xuất</a></li>
                                    <!-- <li><a href="#">Tin tức</a></li></ul> -->
                                </div>
                            </div>
                        </nav>

                    </div>

                </div>

            </div>

        </header>
