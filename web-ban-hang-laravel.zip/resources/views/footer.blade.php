<!--FOOTER-->


    <footer class="site-footer footer-default">

        <div class="footer-main-content_myichi">

            <div class="gb-showroom-footer_myichi">

                <div class="container">

                    <div class="row">

                        <div class="col-md-3">

                            <div class="gb-footer1_myichi">
                                <h4 class="abcd">Thông tin về công ty</h4>

                                <ul>

                                    <li><i class="fa fa-globe" aria-hidden="true"></i> Team 58TH4</li>



                                    <li><i class="fa fa-phone" aria-hidden="true"></i> Số điện thoại: 112121212112</li>

                                    <li><i class="fa fa-map-marker" aria-hidden="true"></i> 175 Tây Sơn Hà Nội </li>

                                    <li><i class="fa fa-envelope-open-o" aria-hidden="true"></i> Email: @@gmail.com</li>


                                </ul>

                            </div>

                        </div>

                        <div class="col-md-3">

                            <div class="gb-footer2_myichi">

                                <h4 class="abcd">Quy định chính sách</h4>

                                <ul>

                                    <li><a href="/chinh-sach-doi-tra">Chích sách đổi trả</a></li>

                                    <li><a href="/phuong-thuc-thanh-toan">Phương thức thanh toán</a></li>

                                    <li><a href="/chinh-sach-van-chuyen">Chính sách vận chuyển</a></li>
                                    <li><a href="/chinh-sach-bao-mat">Chính sách bảo mật</a></li>


                                </ul>


                            </div>

                        </div>

                        <div class="col-md-3">

                            <div class="gb-footer3_myichi">
                                <h4 class="abcd">Kênh Youtube</h4>


                            </div>

                        </div>

                        <div class="col-md-3">

                            <div class="gb-footer3_myichi">
                                <h4 class="abcd">Kênh Fanpage</h4>


                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="copyright-area">

            <div class="container">

                <div class="row"></div>

                <div class="copyright-content">

                    <div class="col-md-12">

                        © Copyright 2020. All rights reserved. Design by Team 58TH4

                    </div>



                </div>

            </div>

        </div>

    </div>

</div>

</footer>
